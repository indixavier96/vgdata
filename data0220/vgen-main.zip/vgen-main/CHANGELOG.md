## [0.2.0] - 2026-01-04

### 🚀 Features

- *(provider)* Add boha data provider (#2)

### 📚 Documentation

- Add crates.io installation method
- Change yay to paru
- Update AGENTS.md with code map and conventions

### ⚙️ Miscellaneous Tasks

- Add `AGENTS.md`
- Add `deepwiki` badge
- Add `context7.json`
## [0.1.0] - 2025-12-17

### 🚀 Features

- Initial release

### ⚙️ Miscellaneous Tasks

- *(release)* V0.1.0
