fn main() -> anyhow::Result<()> {
    vgen::run_from_args(std::env::args())
}
