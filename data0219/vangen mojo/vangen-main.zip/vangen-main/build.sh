#!/bin/sh

mojo build vangen_mojo/__init__.mojo --emit shared-lib -o vangen_mojo.so
