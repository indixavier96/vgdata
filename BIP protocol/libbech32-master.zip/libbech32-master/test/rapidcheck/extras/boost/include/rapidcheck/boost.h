#pragma once

#include <rapidcheck.h>

#include "rapidcheck/gen/boost/Optional.h"
