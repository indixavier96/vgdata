#include "rapidcheck/BeforeMinimalTestCase.h"

namespace rc {

void beforeMinimalTestCase() {}

} // namespace rc
