#pragma once

#include "rapidcheck/Compat.hpp"
