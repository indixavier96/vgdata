#pragma once

#include <chrono>

namespace rc {
namespace gen {

} // namespace gen
} // namespace rc

#include "Chrono.hpp"
